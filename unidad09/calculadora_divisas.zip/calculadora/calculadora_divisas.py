from tkinter import *
from tkinter import ttk
import requests

class Aplicacion():
    cambio_moneda1_EUR = 0
    cambio_moneda2_EUR = 0
    def __init__(self):
        self.raiz = Tk()
        #self.raiz.geometry('300x400')
        self.raiz.configure(bg='beige')
        self.raiz.title('Calculadora Divisas')
        # En este caso width indica el número de caracteres que acepta el texto de ancho y height, el número de líneas.
        self.texto = Text(self.raiz, width=20, height=1)
        self.texto.grid(column=1, row=0, columnspan=2)
        # Creamos menú con resultado
        self.mensajes = Text(self.raiz, width=50, height=5)
        self.mensajes.grid(column=0, row=8, columnspan=3, padx=15, pady=15)
        # Creamos etiqueta moneda a elegir origen
        self.moneda_origen_texto = Label(self.raiz, text="Divisa origen", bg='beige', pady=15, padx=10)
        self.moneda_origen_texto.grid(column=0, row=5)
        # Creamos etiqueta moneda a elegir destino
        self.moneda_destino_texto = Label(self.raiz, text="Divisa destino", bg='beige', pady=15, padx=10)
        self.moneda_destino_texto.grid(column=0, row=6)
        # Creamos combobox con opciones de moneda
        self.moneda_origen = ttk.Combobox(self.raiz, state='readonly')
        self.moneda_origen['values'] = ["EUR", "CAD", "HKD", "ISK", "PHP", "DKK", "HUF", "CZK", "AUD", "RON", "SEK",
                                        "IDR", "INR", "BRL", "RUB", "HRK", "JPY", "THB", "CHF", "SGD", "PLN", "BGN",
                                        "TRY", "CNY", "NOK", "NZD", "ZAR", "USD", "MXN", "ILS", "GBP", "KRW", "MYR"]
        self.moneda_origen.grid(column=1, row=5, columnspan=2)

        # Creamos combobox con opciones de moneda destino
        self.moneda_destino = ttk.Combobox(self.raiz, state='readonly')
        self.moneda_destino['values'] = ["EUR", "CAD", "HKD", "ISK", "PHP", "DKK", "HUF", "CZK", "AUD", "RON", "SEK",
                                        "IDR", "INR", "BRL", "RUB", "HRK", "JPY", "THB", "CHF", "SGD", "PLN", "BGN",
                                        "TRY", "CNY", "NOK", "NZD", "ZAR", "USD", "MXN", "ILS", "GBP", "KRW", "MYR"]
        self.moneda_destino.grid(column=1, row=6, columnspan=2)
        # Creamos etiqueta de texto
        self.inicio = Label(self.raiz, text="Introduce valor", bg='beige', pady=15, padx=10)
        self.inicio.grid(column=0, row=0)

        # Creamos los botones para los números

        boton1 = ttk.Button(self.raiz, text='1', command=self.escribir1)
        boton1.grid(column=0, row=1)

        boton2 = ttk.Button(self.raiz, text='2', command=self.escribir2)
        boton2.grid(column=1, row=1)

        boton3 = ttk.Button(self.raiz, text='3', command=self.escribir3)
        boton3.grid(column=2, row=1)

        boton4 = ttk.Button(self.raiz, text='4', command=self.escribir4)
        boton4.grid(column=0, row=2)

        boton5 = ttk.Button(self.raiz, text='5', command=self.escribir5)
        boton5.grid(column=1, row=2)

        boton6 = ttk.Button(self.raiz, text='6', command=self.escribir6)
        boton6.grid(column=2, row=2)

        boton7 = ttk.Button(self.raiz, text='7', command=self.escribir7)
        boton7.grid(column=0, row=3)

        boton8 = ttk.Button(self.raiz, text='8', command=self.escribir8)
        boton8.grid(column=1, row=3)

        boton9 = ttk.Button(self.raiz, text='9', command=self.escribir9)
        boton9.grid(column=2, row=3)

        boton_punto = ttk.Button(self.raiz, text='.', command=self.escribir_punto)
        boton_punto.grid(column=0, row=4)

        boton0 = ttk.Button(self.raiz, text='0', command=self.escribir0)
        boton0.grid(column=1, row=4)

        boton_borrar = ttk.Button(self.raiz, text='<<', command=self.borrar)
        boton_borrar.grid(column=2, row=4)

        boton_calcular= ttk.Button(self.raiz, text="Calcular", command=self.calcular)
        boton_calcular.grid(column=0, row=7, columnspan=3)

        self.raiz.mainloop()
       # mmbutton = tk.Button(mWindow, height=5, width=20, text="Main Menu", command=mmWindow)
        #mmbutton.grid(row=1, column=1)

    def escribir1(self):
        self.texto.insert(END, 1)
    def escribir2(self):
        self.texto.insert(END, 2)
    def escribir3(self):
        self.texto.insert(END, 3)
    def escribir4(self):
        self.texto.insert(END, 4)
    def escribir5(self):
        self.texto.insert(END, 5)
    def escribir6(self):
        self.texto.insert(END, 6)
    def escribir7(self):
        self.texto.insert(END, 7)
    def escribir8(self):
        self.texto.insert(END, 8)
    def escribir9(self):
        self.texto.insert(END, 9)
    def escribir0(self):
        self.texto.insert(END, 0)
    def escribir_punto(self):
        self.texto.insert(END, '.')
    def calcular(self):
        self.mensajes.delete("1.0", END)
        importe = float(self.texto.get("1.0", END))
        moneda1 = self.moneda_origen.get()
        moneda2 = self.moneda_destino.get()

        if moneda1 == "" or moneda2 == "":
            self.mensajes.insert("1.0", "Selecciona divisas de origen y destino")
            datos = ""
        elif moneda1 == 'EUR' and moneda2 != 'EUR':
            url = "https://api.exchangeratesapi.io/latest?symbols=" + moneda2
            cambio_moneda1_EUR = 1
            datos = self.realizar_llamada(url)
        elif moneda2 == 'EUR' and moneda1 != 'EUR':
            url = "https://api.exchangeratesapi.io/latest?symbols=" + moneda1
            cambio_moneda2_EUR = 1
            datos = self.realizar_llamada(url)
        elif moneda1 != 'EUR' and moneda2 != 'EUR':
            url = "https://api.exchangeratesapi.io/latest?symbols=" + moneda1 + "," + moneda2
            datos = self.realizar_llamada(url)
        elif moneda1 == moneda2:
            self.mensajes.insert("1.0", 'Debes elegir dos divisas diferentes')
            datos = ""

        # Cálculos
        if datos != "":
            # Guardamos el valor del cambio de la moneda1 respecto al euro teniendo en cuenta si alguna moneda pedida es EURO
            if moneda1 != 'EUR':
                cambio_moneda1_EUR = float(datos['rates'][moneda1])
            if moneda2 != 'EUR':
                cambio_moneda2_EUR = float(datos['rates'][moneda2])

            # Convertiomos el valor del importe recibido a EUROS
            valor_importe_EUR = importe / cambio_moneda1_EUR

            # Una vez sabemos el importe recibido en EUROS, lo pasamos al valor de la moneda final.
            valor_importe_moneda2 = valor_importe_EUR * cambio_moneda2_EUR
            self.mensajes.insert("1.0", f'{importe} {moneda1} equivalen a {valor_importe_moneda2} {moneda2}')

    def realizar_llamada(self, url):
        respuesta = requests.get(url)
        if respuesta.status_code != 200:
            print("Error al hacer la petición", respuesta.status_code)
            exit(1)
        datos = respuesta.json()
        return datos

    def borrar(self):
        self.texto.delete("1.0", END)

def main():
    mi_app = Aplicacion()
    return 0

if __name__ == '__main__':
    main()

